package p1;

public class Q {

	public static void main(String[] args) {
		P obj=new P();
		obj.display();

	}

}
