package p1;
public class P{
 private void display() {
	 System.out.println("TNS SESSION");
 }
}

