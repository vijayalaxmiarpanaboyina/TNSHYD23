package p1;

public class MyClass1 {
	void display() {
		System.out.println("Hello World");
	}

}
