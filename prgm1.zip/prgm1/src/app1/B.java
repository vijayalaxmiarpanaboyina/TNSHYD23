package app1;

public class B {
	int b=20;
	static int c=30;
	int display() {
		return 10;
	}
	 static void display1() {
		 System.out.println(20);
	}
	public static void main(String[] args) {
		int a=10;
		System.out.println("a");
		B b1=new B();
		System.out.println(b1.b);
		System.out.println(B.c);
		b1.display();
		B.display1();
		
	}

}
