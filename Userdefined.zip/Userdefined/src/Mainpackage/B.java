package Mainpackage;
import pack.*;
import Subpackage.*;

public class B {

	public static void main(String[] args) {
		C obj=new C();
		A obj1=new A();
		D obj2=new D();
		obj.msg();
		obj1.msg();
		obj2.msg();

	}

}
