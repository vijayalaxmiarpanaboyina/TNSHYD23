package Subpackage;

public class D {
	public void msg() {
		System.out.println("Hello D");
	}

}
